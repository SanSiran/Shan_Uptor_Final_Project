import pandas as pd


import numpy as np


from matplotlib import pyplot as plt

from sklearn.model_selection import train_test_split




"""NOTE - The Auto MPG dataset is a regression problem rather than a classification problem, but 
in the below program i have tried KNeighborsClassifier class instead of the KNeighborsRegressor class.
but KNN is slow with large datasets, sensitive to outliers"""

"""Reason behind the Objective - In the Auto MPG dataset, if we are considering the "MPG" (miles 
per gallon) as the target variable and treating it as categorical, then "X" would represent the 
features like horsepower, weight, cylinders (all the other columns in the dataset) and "Y" would 
represent the categorical MPG value -------->{(e.g., "Excellent (1) = 37 to 46.6 mpg", 
"Very Good (6) = 27.5 to 37 mpg",   "Very Poor (7) = Below 15 mpg",    "Good (3) = 20 to 27 mpg", 
"Poor (4) = 15 to 20 mpg")}   ------ making it a multi-classification problem because we are 
predicting one of multiple categories of MPG. """

"""To implement KNN in Python, libraries like scikit-learn, numpy, and scipy are often used. 
These libraries offer functions for data preprocessing, model fitting, and prediction."""

df = pd.read_csv("auto2_mpg.csv")
print("------------------------------------------------------------------------------A1")

###### Part -1 ######

# Pre-processing

shape = df.shape
print(shape)
print("---------------------------------------------------------------------A2")

sample_data_check =df.head()
print(sample_data_check)
print("---------------------------------------------------------------------A3")

col_names = df.columns
print(col_names)
print("---------------------------------------------------------------------A4")

# view summary of dataset
df.info()
print("---------------------------------------------------------------------A5")
df.dtypes
print("---------------------------------------------------------------------A6")

columns_df = df[['mpg', 'cylinders', 'horsepower', 'weight', 'acceleration', 'rating']]
print(columns_df)
print("---------------------------------------------------------------------A7")

"""In above output --While all the columns look fine, we notice that horsepower has the data type
object. But we would expect horsepower to have a data type of either integer or 
float. So in this context we need to probe it further."""


pd.set_option("display.max_columns",None)
pd.set_option("display.max_rows",None)
print(df)
print("________________________________________________________________________A8")

finding_nan_column_sum = df['mpg'].isna().sum()
print(finding_nan_column_sum)
print("_____________________________________________________________________A9")

finding_nan_column_sum = df[ 'cylinders'].isna().sum()
print(finding_nan_column_sum)
print("_____________________________________________________________________A10")


finding_nan_column_sum = df['horsepower'].isna().sum()
print(finding_nan_column_sum)
print("_____________________________________________________________________A11")

finding_nan_column_sum = df['weight'].isna().sum()
print(finding_nan_column_sum)
print("_____________________________________________________________________A12")

finding_nan_column_sum = df['acceleration'].isna().sum()
print(finding_nan_column_sum)
print("_____________________________________________________________________A13")

finding_nan_column_sum = df['rating'].isna().sum()
print(finding_nan_column_sum)
print("_____________________________________________________________________A14")

"""In above output -- We find that the missing values of horsepower are represented by 'NaN'. This 
is causing it to assume the object datatype.

There are multiple ways to handle such missing values. We can substitute the missing value by the 
median since it is resistant to outliers unlike the mean. However, in our case we are just ignoring 
the missing values by dropping the rows which have a 'NaN' in the horsepower column."""

"""But -- In above output-- horsepower does not have any missing values or null values. We would 
however like to check what all horsepower assumes!"""


# Convert horsepower column to numeric type
df['horsepower'] = pd.to_numeric(df['horsepower'])
print(df['horsepower'])
print("------------------------------------------------------------------------------A15")


# Drop any rows with NaN values
df.dropna(inplace=True)
print(df)
print("------------------------------------------------------------------------------A16")


from sklearn.preprocessing import LabelEncoder

Label_encoding_object = LabelEncoder()
df['Rating'] = Label_encoding_object.fit_transform(df['rating'])
print(df)
print("__________________________________________________________________________A17")


"""to read more than one column data"""
column_data = df[['mpg', 'cylinders', 'horsepower', 'weight', 'acceleration', 'rating']]
print(column_data)
print("----------------------------------------------------------------------------A18")

# Define features (X) and target (y)
X = df[['cylinders', 'horsepower', 'weight', 'acceleration', 'rating']]
y = df['mpg']
print("------------------------------------------------------------------------------A19")



# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(df.drop('mpg', axis=1), df['mpg'],
                                                    test_size=0.2, random_state=42)
print("------------------------------------------------------------------------------A20")


###### Part -2 ######

from sklearn.neighbors import KNeighborsClassifier

# Create ------> a k-NN Classifier model
knn = KNeighborsClassifier(n_neighbors=4)
print(df.mpg)
print("------------------------------------------------------------------------------A21")

# plot histograms of the variables
plt.rcParams['figure.figsize']=(20,15)
df.plot(kind='hist', bins=10, subplots=True, layout=(5,2), sharex=False, sharey=False)
plt.show()
print("------------------------------------------------------------------------------A22")


from sklearn.neighbors import KNeighborsClassifier

# instantiate the model with k=4
knn_4 = KNeighborsClassifier(n_neighbors=4)
print(df.mpg)
print("-------------------------------------------------------------------------A23")




# Test the model - actual & predict
print("actual:",y_test) #actual data is y_test
print("-------------------------------------------------------------------------A24")
print("predict:", y_test) #actual data is y_test
print("-------------------------------------------------------------------------A25")

"""The above output (in detail attached in "Inference_1_auto2_mpg_Knn_Classifier")-- described 
as below"""

"""x1('Y' Target) &   x2  x3  x4  x5 ('X' Features) ---> Assume that four types of columns - KNN 
algorithm (supervised learning) will analyse the four columns (n_neighbors=4) and gives us 2 
components(new two columns) as a, b ( we need to setup it with with a column name)

Ex., if we have 10 feature data ( x data) and try to give it to our target (y) it is difficult for 
the ML & model to work it out -- in that situation we dont know which is best and worst feature 
data - to proceed -- in that situation KNN algorithm (Similar to PCA) will help us to extract the 
best feature data and gives us two new inputs and we need to setup it with a column name"""

"""Observation--
@ KNN is a popular and simple classification and regression classifier. 
@ It's used to label unknown data points based on existing labeled data. 
@ It's used to make predictions about the grouping of an individual data point.
That is looking at the nearest data points, or "neighbors," to make predictions. For 
multi-class problems, it gives the most frequent class among the k neighbors. """



###### Part -3 ######
# Data visualization ---> for better understanding towards --> data Characteristics & their patterns
"""The dependent variable miles per gallon and independent variables horsepower, 
acceleration, weight, and number of engine cylinders, we can conclude that there is a statistically 
significant relationship between miles per gallon, horsepower, acceleration and weight. The 
relationship between miles per gallon is negative for both horsepower, weight and acceleration and 
weight. This negative relationship means that for every increase in horsepower or weight, there 
will likely be a decrease in miles per gallon."""

mpg = pd.read_csv("auto2_mpg.csv")

# Import Matplotlib and Seaborn
import matplotlib.pyplot as plt
import seaborn as sns

# Create scatter plot of horsepower vs. mpg
g = sns.relplot(x="horsepower", y="mpg",
            data=mpg, kind="scatter",
            size="cylinders", hue="cylinders")

# Show plot
plt.show()
print("-------------------------------------------------------------------------A25")
# Create point plot
sns.catplot(x="acceleration",
            y="mpg",
            data=mpg,
            kind="point",
            join=False,
            capsize=0.1)

# Rotate x-tick labels
plt.xticks(rotation=90)

# Show plot
plt.show()
print("-------------------------------------------------------------------------A26")


# "car weight distribution"
# plot a distribution of car weight

plt.figure(figsize=(10,5))
sns.histplot(x = 'weight', data = df, color = '#4287f5')
plt.title("car weight distribution", fontsize = 20)
plt.xlabel("car weight", fontsize = 15)
plt.ylabel("car count", fontsize = 15)
plt.show()
print("-------------------------------------------------------------------------A27")


# Create scatter plot
g = sns.relplot(x="weight",
                y="horsepower",
                data=mpg,
                kind="scatter")

# Add a title "Car Weight vs. Horsepower"
g.fig.suptitle("Car Weight vs. horsepower")
plt.show()
print("-------------------------------------------------------------------------A28")

# mpg increases  weight decreases over time that indicates a strong correlation between them
# plotting weight against mpg

plt.figure(figsize=(10,5))
plt.scatter(x = 'mpg', y = 'weight', data = df)
plt.title("weight against mpg", fontsize = 20)
plt.xlabel("mpg", fontsize = 15)
plt.ylabel("car weight", fontsize = 15)
plt.show()
print("-------------------------------------------------------------------------A29")

# plotting horsepower against acceleration
plt.figure(figsize=(10,5))
plt.scatter(x = 'horsepower', y = 'acceleration', data = df)
plt.title("horsepower against acceleration", fontsize = 20)
plt.xlabel("horsepower", fontsize = 15)
plt.ylabel("acceleration", fontsize = 15)
plt.show()
print("-------------------------------------------------------------------------A30")






